CAPTCHA-THZ v2.1 — Cloudflare Pages

Files in this package:
- index.html
- functions/api/thz-captcha/recaptcha/verify.js

Setup:
1. Deploy this package to Cloudflare Pages (the functions/ folder must be at project root).
2. In Google reCAPTCHA Admin Console, confirm the new public Site Key is configured as reCAPTCHA v2 Checkbox. Add every deployed hostname, including the *.pages.dev hostname if used.
3. Set RECAPTCHA_SECRET_KEY as a Cloudflare Pages Secret. It must be the matching Secret Key paired with the new public Site Key embedded in index.html. Do not put the Secret Key in HTML.
4. Set RECAPTCHA_ALLOWED_HOSTNAMES as a comma-separated list of exact allowed hostnames, e.g. example.com,www.example.com,my-project.pages.dev.
5. Redeploy after changing the variables or functions.

The browser first loads Google's official api.js host. If that host cannot be reached, it falls back to www.recaptcha.net. The backend uses the same alternate host if Google's verification endpoint cannot be reached. This fallback does not fix an invalid key, a wrong key type, an unregistered domain, or a mismatched Secret Key.

B2 checks the slider automatically after the user releases the range control. A miss creates another image and another cut-out position; a correct placement advances to the next round.

The Google reCAPTCHA widget is the final check. Its response token is validated by the Cloudflare Pages Function before the success screen is shown.
