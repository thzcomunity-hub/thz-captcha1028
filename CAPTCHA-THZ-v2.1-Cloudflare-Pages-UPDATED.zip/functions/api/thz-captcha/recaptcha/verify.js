export async function onRequestPost({ request, env }) {
  const json = (body, status = 200) => new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
  });

  if (!env.RECAPTCHA_SECRET_KEY) {
    return json({ ok: false, message: "Chưa cấu hình Secret Key reCAPTCHA trên Cloudflare Pages." }, 503);
  }
  const allowed = String(env.RECAPTCHA_ALLOWED_HOSTNAMES || "")
    .split(",").map(x => x.trim().toLowerCase()).filter(Boolean);
  if (!allowed.length) {
    return json({ ok: false, message: "Chưa cấu hình tên miền được phép trong RECAPTCHA_ALLOWED_HOSTNAMES." }, 503);
  }

  let body;
  try { body = await request.json(); }
  catch { return json({ ok: false, message: "Dữ liệu xác minh không hợp lệ." }, 400); }
  const token = typeof body?.token === "string" ? body.token.trim() : "";
  if (!token || token.length > 8192) {
    return json({ ok: false, message: "Google chưa cấp token xác minh hợp lệ." }, 400);
  }

  try {
    const form = new URLSearchParams({ secret: env.RECAPTCHA_SECRET_KEY, response: token });
    let upstream = null;
    let networkError = null;
    // Google documents recaptcha.net as an alternate host in regions/networks
    // where www.google.com cannot be reached.
    for (const endpoint of [
      "https://www.google.com/recaptcha/api/siteverify",
      "https://www.recaptcha.net/recaptcha/api/siteverify",
    ]) {
      try {
        upstream = await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: form,
        });
        if (upstream.ok) break;
        networkError = new Error(`HTTP ${upstream.status}`);
      } catch (error) {
        networkError = error;
      }
    }
    if (!upstream || !upstream.ok) {
      return json({ ok: false, message: "Không kết nối được dịch vụ xác minh Google reCAPTCHA." }, 502);
    }
    const result = await upstream.json();
    if (result.success !== true) {
      const codes = Array.isArray(result["error-codes"]) ? result["error-codes"] : [];
      let message = "Google chưa xác nhận lượt reCAPTCHA. Hãy thử lại.";
      if (codes.includes("invalid-input-secret") || codes.includes("missing-input-secret")) {
        message = "Secret Key không đúng hoặc chưa được cấu hình. Hãy dùng Secret Key cùng cặp với Site Key mới.";
      } else if (codes.includes("invalid-input-response") || codes.includes("timeout-or-duplicate")) {
        message = "Token đã hết hạn hoặc đã được sử dụng. Hãy xác minh lại.";
      } else if (codes.includes("missing-input-response")) {
        message = "Thiếu token do Google reCAPTCHA cấp.";
      }
      return json({ ok: false, message, errors: codes }, 403);
    }
    const hostname = String(result.hostname || "").toLowerCase();
    if (!allowed.includes(hostname)) {
      return json({ ok: false, message: "Tên miền hiện tại chưa được cho phép cho Site Key này." }, 403);
    }
    return json({ ok: true, hostname, challenge_ts: result.challenge_ts || null });
  } catch {
    return json({ ok: false, message: "Không thể kết nối máy chủ xác minh Google." }, 502);
  }
}
